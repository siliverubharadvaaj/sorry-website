# 💞 Sorry Website

This is a special website made to say sorry in a sweet and creative way.  
You can customize it with your own letter, photos, and even add a background song to make it more personal.

---

## ✨ What You Can Customize

- Your own apology letter text  
- Add photos to make it special  
- Add a background song to set the mood  

---

## 🛠️ Tech Stack

- Next.js  
- Tailwind CSS  
- Framer Motion (for smooth animations)  

---

## 👋 About Me

Hey! I'm **Sulaiman**, a web developer and student who loves building unique websites like this to help people express feelings online.


---

Thank you for checking out this project! If you like it, please ⭐ star the repo and share it with your friends.

---

_Made with 💖 by Sulaiman_
